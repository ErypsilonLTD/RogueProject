Thank you for downloading Rogue Project!

Steps for first run [These do not need to be reperformed between sessions or updates!]:
1. Open Settings and follow the steps below
 Windows 10:
  Time & Language → Language → Administrative language settings → Change system locale → Beta: Use Unicode UTF-8 for world-wide language support
 Windows 11:
  Time & Language → Language & Region → Windows display language → Beta: Use Unicode UTF-8 for world-wide language support
  System → Advanced → Terminal → Windows Console Host

2. Download .Net from Google at this link >https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.102/dotnet-sdk-10.0.102-win-x64.exe<
3. Possibly lower your system volume as the ingame sound engine is loud
4. Run Rogue Project.exe found in this folder
5. If Windows Defender opens with "Windows protected your PC" press More info → Run anyway
6. When the console loads, press F11 (Alt + Enter also applicable for 60% keyboards) and zoom to fill
7. Enjoy <3